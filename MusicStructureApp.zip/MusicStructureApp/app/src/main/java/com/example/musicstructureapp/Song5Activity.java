package com.example.musicstructureapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Song5Activity extends AppCompatActivity {

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song5);
    }
}
